const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
module.exports = {
    entry: {
      main: ['./src/app.js', './src/scss/App.scss'],
    },
    mode: 'development',
    resolve: {
      extensions: ['.js', '.jsx']
    },
    module: {
      rules: [
        {
          test: /\.js$|jsx/,
          exclude: /node_modules/,
          loader: 'babel-loader',
          query:
          {
            presets:['react']
          }
        },
        {
          test: /\.s?[ac]ss$/,
          use: [
              MiniCssExtractPlugin.loader,
              { loader: 'css-loader', options: { url: false, sourceMap: true } },
              { loader: 'sass-loader', options: { sourceMap: true } }
          ],
        }
      ]
    },
    output: {
        path: path.join(__dirname,'dist'),
        filename: 'script/bundle.js'
    },
    plugins: [
        new MiniCssExtractPlugin({
          filename: "./css/styles.css"
        }),
        new HtmlWebpackPlugin({
          template: './src/index.html',
          filename: './index.html'
        })
    ],
    watch: true
    
  };