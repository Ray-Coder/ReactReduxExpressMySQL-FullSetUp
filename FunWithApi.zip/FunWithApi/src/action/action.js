import {API_REQUEST, DISPATCH_TODO_CALL, API_ERROR, INPUT_TEXT, INPUT_TEXT_ID, INPUT_TEXT_TASK} from '../constants/constant'
import {CALL_API} from '../middleware/api';

const apiCall = (type, value, method, req) => ({
    [CALL_API]: {
        types: [API_REQUEST, type, API_ERROR],
        value,
        method,
        req
    }
})

export const makeGetApiCall = (value, method, req) => dispatch => dispatch(
    apiCall(DISPATCH_TODO_CALL,value, method, req)
)
//value is todos, methods is GET/POST
export const updateText = (value, textType) => {
    switch (textType){
        case 'URL':
        return {
            type: INPUT_TEXT,
            value
        }
        case 'ID':
            return {
                type: INPUT_TEXT_ID,
                value
            }
        case 'TASK':
            return {
                type: INPUT_TEXT_TASK,
                value
            }
        case 'default':
            break;
    }
        
}