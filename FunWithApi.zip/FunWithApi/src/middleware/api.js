import fetch from 'isomorphic-fetch';

export const CALL_API = 'Call API';

const callAPIMethods = (url, method, requestParam = {}) => {
    const reqData = (method !== "GET")?{
        method: method, // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
        credentials: "same-origin", // include, *same-origin, omit
        headers: {
            "Content-Type": "application/json",
            // "Content-Type": "application/x-www-form-urlencoded",
        },
        redirect: "follow", // manual, *follow, error
        referrer: "no-referrer", // no-referrer, *client
        body: JSON.stringify(requestParam)
    }:
    {}
    return fetch(url,reqData)
    .then(response => response.json()
      .then((json) => {
        if (!response.ok) {
          return Promise.reject(json);
        }

        return json
      }),
    );
    
}
const myResponseHandler = (response) => {
    console.log(response);
    return response;
}
const myErrorHandler = (error) => {
    console.log(error);
    return error;
}
const callApi = (url, method, requestData) => callAPIMethods(url, method, requestData)
    .then(response => myResponseHandler(response), error => myErrorHandler(error))

export default store => next => (action) => {
    const callAPI = action[CALL_API]

    if (typeof callAPI === 'undefined') {
        return next(action)
    }
    let { endpoint } = callAPI
    const { types } = callAPI
    if (typeof endpoint === 'function'){
        endpoint = endpoint(store.getState())
    }
    const actionWith = (data) => {
        const finalAction = Object.assign({}, action, data)
        delete finalAction[CALL_API]
        return finalAction
    }
    const [ requestType, successType, errorType ] = types
    next(actionWith({ type: requestType }))

    return callApi(callAPI.value, callAPI.method, callAPI.req).then(
        response => next(actionWith({
            response, 
            type: successType
        })),
        error => next(actionWith({
            type: errorType,
            error: error.message || 'Error!'
        }))
    )
}

