import React,{Component} from 'react';
import Journey from './component/journey.jsx'
import ReactDOM from 'react-dom';
import configureStore from './store/store'

const store = configureStore();
const app = <Journey store ={store} />

ReactDOM.render(app, document.getElementById('root'));