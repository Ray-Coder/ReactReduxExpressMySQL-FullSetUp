export const GET_CALL = 'GET';
export const API_REQUEST = 'API_REQUEST';
export const DISPATCH_TODO_CALL = 'DISPATCH_TODO_CALL';
export const API_ERROR = 'API_ERROR';
export const API_REQUEST_NAME = '/todos';
export const INPUT_TEXT = 'INPUT_TEXT';
export const INPUT_TEXT_ID = 'INPUT_TEXT_ID';
export const INPUT_TEXT_TASK = 'INPUT_TEXT_TASK';

