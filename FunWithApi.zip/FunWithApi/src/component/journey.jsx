import React, {Component} from 'react'
import {Route, Switch, HashRouter} from 'react-router-dom'
import {Provider} from 'react-redux'

import Header from './header'
import Footer from './footer'
import Page from './body'

class Journey extends Component{
    render (){
        return (
            <Provider store={this.props.store} >
                <Header title="Fun with APIs" />
                <HashRouter>
                    <div>
                        <Switch>
                            <Route component={Page} exact path="/" />
                        </Switch>
                    </div>
                </HashRouter>
                <Footer title="Powered by React16"/>
            </Provider>
        )
    }
}
export default Journey;