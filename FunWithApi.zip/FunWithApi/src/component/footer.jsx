import React,{Component} from 'react';
class Footer extends Component {
        render(){
            return (
                <div className="footerStyle">
                    <h3>{this.props.title}</h3>
                </div>
            )
        } 

}

module.exports = Footer;