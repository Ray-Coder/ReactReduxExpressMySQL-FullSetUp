import React,{Component} from 'react';
import {connect} from 'react-redux'
import {withRouter} from 'react-router-dom'
import {updateText} from '../action/action'

class InputText extends Component {
        constructor(props){
            super(props)
            this.onChangeHandler = this.onChangeHandler.bind(this)
        }
        onChangeHandler(e){
            this.props.dispatch(updateText(e.target.value,this.props.boxType))
        }
        render(){
            return (
                <div className="textDiv">
                    <input type="text" className={this.props.classType} placeholder="Type API name E.g /todos " onChange={this.onChangeHandler}/>
                </div>
            )
        } 

}
function mapStateToProps(state){
    return state;
}
export default withRouter(connect(mapStateToProps)(InputText))
