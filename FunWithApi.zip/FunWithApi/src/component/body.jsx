import React,{Component} from 'react'
import {connect} from 'react-redux'
import {withRouter} from 'react-router-dom'
import {makeGetApiCall} from '../action/action'
import InputText from './inputText'
class Page extends Component {
        constructor(props){
            super(props)
            this.makeApiCallHandler = this.makeApiCallHandler.bind(this)
            this.displayResult = this.displayResult.bind(this)
        }
        makeApiCallHandler(e){
            const req = {};
            if(this.props.id && this.props.task){
                req["id"] = this.props.id;
                req["task"] = this.props.task;
            }
            this.props.dispatch(makeGetApiCall(this.props.text, e.target.value,req))
        }
        displayResult(){
            if(this.props.getResp){
                let dataDisp = (this.props.getResp.data.length > 1)? this.props.getResp.data.map((item, index) => {
                    return (
                        <tr key={index}>
                            <td>{item.id}</td>
                            <td>{item.task}</td>
                        </tr> 
                    )
                }) : <tr key="1"><td>{this.props.getResp.message}</td></tr>
                return (
                    <table className="displayTable">
                        <tbody>
                        <tr>
                            <th> ID  </th>
                            <th> TASK </th>
                        </tr>
                        {dataDisp}
                        </tbody>
                    </table>
                )
            }
            else{
                return (<h3 className="displayMsg">Results will be displayed here!</h3>)
            }
            
        }
        render(){
            return (
                <div>
                    <div className="bodyStyle">
                        <InputText boxType="URL" classType="textStyle" />
                        <InputText boxType="ID" classType="textStyleSmall" />
                        <InputText boxType="TASK" classType="textStyleSmall" />
                        <div className="selectDiv">
                            <select className="selectStyle" onChange={this.makeApiCallHandler}>
                                <option >Select Request Type</option>
                                <option value="GET">GET</option>
                                <option value="POST">POST</option>
                                <option value="PUT">UPDATE</option>
                                <option value="DELETE">DELETE</option>

                            </select>
                        </div>
                    </div>
                    <div className="bodyStyle">
                        <div className="displayResults">
                        {this.displayResult()}
                        </div>
                    </div>
                </div>
                
            )
        } 

}

function mapStateToProps(state){
    return {
        getResp : state.callTodoGetMethod.getResp,text: (state.updateTextDisplay.text)? state.updateTextDisplay.text : "",
        id: (state.updateTextDisplayID.id)?state.updateTextDisplayID.id:"",
        task: (state.updateTextDisplayTask.task)?state.updateTextDisplayTask.task:""
    };
}
export default withRouter(connect(mapStateToProps)(Page))



