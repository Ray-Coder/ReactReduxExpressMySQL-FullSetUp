import {combineReducers} from 'redux';
import { DISPATCH_TODO_CALL, API_REQUEST, API_ERROR } from '../constants/constant';

function callTodoGetMethod(state={},action){
    switch (action.type){
        case API_REQUEST:
            return {
                loading: true,
                error: null
            }
        case DISPATCH_TODO_CALL:
            return Object.assign({}, { getResp: action.response }) 
        case API_ERROR:
            return {
                loading: false,
                error: action.error,
            }
        default:
            return state;
    }
}

function updateTextDisplay(state = {}, action) {
    switch (action.type) {
        case 'INPUT_TEXT':
            return Object.assign({}, { text: action.value }, action)
        default:
            return state
    }
  }
function updateTextDisplayID(state = {}, action) {
    switch (action.type) {
        case 'INPUT_TEXT_ID':
            return Object.assign({}, { id: action.value }, action)
        default:
            return state
    }
}
function updateTextDisplayTask(state = {}, action) {
    switch (action.type) {
        case 'INPUT_TEXT_TASK':
            return Object.assign({}, { task: action.value }, action)
        default:
            return state
    }
}

const rootReducer = combineReducers({
    callTodoGetMethod,
    updateTextDisplay,
    updateTextDisplayID,
    updateTextDisplayTask
});

export default rootReducer;