import { applyMiddleware, compose, createStore } from 'redux';
import thunk from 'redux-thunk';
import api from '../middleware/api';
import rootReducer from '../reducer/reducer';

const configureStore = () => {
    const store = createStore(
        rootReducer,
        compose(
            applyMiddleware(thunk, api)
        )
        
    );
    return store;
}
export default configureStore;